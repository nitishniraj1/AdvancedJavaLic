	
	package com.java.layer3;

	import java.util.List;

	import com.java.layer2.Flight;

	public interface FlightRepository {
		
		void insertFlight(Flight flight); // create
		void upadteFlight(Flight flight); // update
		void deleteFlight(int flightNumber);  //delete
		Flight searchFlight(int flightNumber); //Read
		List<Flight> searchFlights();
		
		List<Flight> searchFlights(String source, String target);

	}


