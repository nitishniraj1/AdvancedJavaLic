package com.java.layer2;

import java.sql.Timestamp;

public class Flight {
	
	private int flightNumber;
	private String flightsource;
	private String flightDestination;
	private Timestamp flightDepartureDate;  //java.sql
	
	public Flight(int flightNumber, String flightsource, String flightDestination, Timestamp flightDepartureDate) {
		super();
		this.flightNumber = flightNumber;
		this.flightsource = flightsource;
		this.flightDestination = flightDestination;
		this.flightDepartureDate = flightDepartureDate;
	}

	public int getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFlightsource() {
		return flightsource;
	}

	public void setFlightsource(String flightsource) {
		this.flightsource = flightsource;
	}

	public String getFlightDestination() {
		return flightDestination;
	}

	public void setFlightDestination(String flightDestination) {
		this.flightDestination = flightDestination;
	}

	public Timestamp getFlightDepartureDate() {
		return flightDepartureDate;
	}

	public void setFlightDepartureDate(Timestamp flightDepartureDate) {
		this.flightDepartureDate = flightDepartureDate;
	}
	
	
	
	

}
