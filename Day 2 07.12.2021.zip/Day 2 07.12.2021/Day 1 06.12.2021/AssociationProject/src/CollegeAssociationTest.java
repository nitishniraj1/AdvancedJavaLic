
public class CollegeAssociationTest {

	public static void main(String[] args) {
		System.out.println("Hello CollegeAssociation....");

		
		TextBook myTextBook[] = {
				new TextBook(),
				new TextBook(),
				new TextBook()
		};
		
		Onlinelink onlinelink = new Onlinelink();
		Mobilelearningapplication mobilelearningapplication  = new Mobilelearningapplication();
		
		GoodKnowledge toughPaper = new GoodKnowledge();
		
		EnglishTeacher et = new EnglishTeacher();
		
		Examination theexamination = et.questionPaper(myTextBook , onlinelink , mobilelearningapplication );
		theexamination.result();
	}

}

class GoodTeacher {}
class GoodKnowledge extends GoodTeacher { }  //isA

class Principal { }
class EnglishTeacher extends Principal 
{ // isA
	GoodKnowledge goodKnowledge  = new GoodKnowledge();  // hasA
	
	//producesA           usesA           usesA         usesA           
	Examination questionPaper(TextBook t[], Onlinelink o, Mobilelearningapplication ma)
	{
		System.out.println("Examination.....");
		Examination examination = new Examination();
  		examination.marks = t.length * 50;
		return examination;
	}
	
} 


class Examination { 
	float marks;
	
	void result () {
		System.out.println("Examination Marks is:"+marks);
	}
		
	}
	
class TextBook {}
class Onlinelink { }
class Mobilelearningapplication {}
