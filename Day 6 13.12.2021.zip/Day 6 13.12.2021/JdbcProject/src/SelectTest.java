import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.java.entity.Department;

public class SelectTest {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		/*
		 * // 1. load the driver
		 * 
		 * try { DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		 * 
		 * System.out.println("Driver register...");
		 * 
		 * //2
		 * 
		 * Connection conn =
		 * DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system",
		 * "tiger"); System.out.println("Connected to DB: "+conn);
		 * 
		 * //3
		 * 
		 * Statement statement = conn.createStatement();
		 * System.out.println("Statement Created");
		 * 
		 * ResultSet result = statement.executeQuery("select * from dept");
		 * System.out.println("Got The result set: " + result);
		 * 
		 * 
		 * while(result.next()) { Department deptObj = new Department();
		 * deptObj.setDepartmentNumber(result.getInt(1));
		 * deptObj.setDepartmentName(result.getString(2));
		 * deptObj.setDepartmentLocation(result.getString(3));
		 * 
		 * System.out.println("Dept No :" +deptObj.getDepartmentLocation());
		 * System.out.println("Dept Name:"+deptObj.getDepartmentName());
		 * System.out.println("Dept Location:"+deptObj.getDepartmentLocation());
		 * 
		 * int x = result.getInt(1); String y = result.getString(2); String z =
		 * result.getString(3);
		 * 
		 * System.out.println("x :"+x+ " y :"+y+ " z :"+z);
		 * System.out.println(x+"\t"+y+"\t"+z);
		 * System.out.println("-------------------------------");
		 * 
		 * }
		 * 
		 * } catch (SQLException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } System.out.println("Driver Registered");
		 */

	}

}
