package onetomany;

public class Employee {

}
