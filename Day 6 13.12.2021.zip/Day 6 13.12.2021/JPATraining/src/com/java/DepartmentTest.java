package com.java;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.entity.Department;

public class DepartmentTest {

	@Test
	public  void insertTest() {
		
		EntityManagerFactory entityManagerFactory =
				Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Entity manager : "+entityManager);

		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
			Department dept = new Department();//transient 
			dept.setDepartmentNumber(60);
			dept.setDepartmentName("UNIXTRG");
			dept.setDepartmentLocation("pune");
			entityManager.persist(dept); //insert query
		entityTransaction.commit();
		
	}

	@Test
	public  void selectTest() {
		
		EntityManagerFactory entityManagerFactory =
				Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Entity manager : "+entityManager);

		EntityTransaction entityTransaction = entityManager.getTransaction();
		
		Department dept = null;
		dept  = entityManager.find(Department.class, 10);  // attached object case - because 10 data is present in database.
		//dept  = entityManager.find(Department.class, 90);  // transient case - because 90 data is present in database.
 
		System.out.println("DeptNo: "+dept.getDepartmentNumber());
		System.out.println("DeptNo: "+dept.getDepartmentName());
		System.out.println("DeptNo: "+dept.getDepartmentLocation());

		
	}
	
	@Test
	public  void updateTest() {
		
		EntityManagerFactory entityManagerFactory =
				Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Entity manager : "+entityManager);

		Department dept = null;
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		
		dept  = entityManager.find(Department.class, 40);
		
		Assertions.assertNotNull(dept);
		
 		System.out.println("DeptNo: "+dept.getDepartmentNumber());
		System.out.println("DeptNo: "+dept.getDepartmentName());
		System.out.println("DeptNo: "+dept.getDepartmentLocation());
		
			 
			dept.setDepartmentName("TRAINING");
			dept.setDepartmentLocation("BORIVALI");
			entityManager.persist(dept); //insert query
			entityManager.merge(dept);
		entityTransaction.commit();

		
	}
	
	@Test
	public  void deleteTest() {
		
		EntityManagerFactory entityManagerFactory =
				Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Entity manager : "+entityManager);

		Department dept = null;
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		
		dept  = entityManager.find(Department.class, 60);  // only attached data can be removed but transient data cann't be removed
 		System.out.println("DeptNo: "+dept.getDepartmentNumber());
		System.out.println("DeptNo: "+dept.getDepartmentName());
		System.out.println("DeptNo: "+dept.getDepartmentLocation());
			
		entityManager.remove(dept);

		entityTransaction.commit();

		
	}
	
	@Test
	public  void selectAllTest() {
		
		EntityManagerFactory entityManagerFactory =
				Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Entity manager : "+entityManager);

	
		Query query = entityManager.createQuery("from Department");// JPQL query
		List<Department> deptList = query.getResultList();
		
		for(Department dept: deptList)
		{
	 		System.out.println("DeptNo: "+dept.getDepartmentNumber());
			System.out.println("DeptNo: "+dept.getDepartmentName());
			System.out.println("DeptNo: "+dept.getDepartmentLocation());
			System.out.println("-----------------------------------");
			
		}
		
	}
}