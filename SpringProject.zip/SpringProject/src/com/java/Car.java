package com.java;

public class Car {

}
