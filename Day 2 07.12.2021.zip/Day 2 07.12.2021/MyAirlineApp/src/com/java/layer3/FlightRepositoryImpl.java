package com.java.layer3;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.Flight;

public class FlightRepositoryImpl implements FlightRepository {

	
	
	ArrayList<Flight> flightList = new ArrayList<Flight>();
	
	public FlightRepositoryImpl()
	{
		System.out.println("FlightRepositoryImpl() Constructor....");
		
		Flight flight1 = new Flight(101, "Mumbai", "London", Timestamp.valueOf("2021-12-14 23:23:45"));	
		Flight flight2 = new Flight(101, "Mumbai", "London", Timestamp.valueOf("2021-12-14 23:23:45"));	
		Flight flight3 = new Flight(101, "Mumbai", "Paris", Timestamp.valueOf("2021-12-14 23:23:45"));	
		Flight flight4 = new Flight(101, "Mumbai", "Paris", Timestamp.valueOf("2021-12-14 23:23:45"));	
		Flight flight5 = new Flight(101, "Mumbai", "Russia", Timestamp.valueOf("2021-12-14 23:23:45"));	
		
		Flight flight6 = new Flight(101, "Mumbai", "Russia", Timestamp.valueOf("2021-12-14 23:23:45"));	
		Flight flight7 = new Flight(101, "Mumbai", "Patna", Timestamp.valueOf("2021-12-14 23:23:45"));	
		Flight flight8 = new Flight(101, "Mumbai", "Patna", Timestamp.valueOf("2021-12-14 23:23:45"));	
		Flight flight9 = new Flight(101, "Mumbai", "Kolkata", Timestamp.valueOf("2021-12-14 23:23:45"));	
		Flight flight10 = new Flight(101, "Mumbai", "Kolkata", Timestamp.valueOf("2021-12-14 23:23:45"));	

		
		flightList.add(flight1);
		flightList.add(flight2);
		flightList.add(flight3);
		flightList.add(flight4);
		flightList.add(flight5);
		
		flightList.add(flight6);
		flightList.add(flight7);
		flightList.add(flight8);
		flightList.add(flight9);
		flightList.add(flight10);
		
	}
	
	@Override
	public void insertFlight(Flight flight) {
		// TODO Auto-generated method stub

	}

	@Override
	public void upadteFlight(Flight flight) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteFlight(int flightNumber) {
		// TODO Auto-generated method stub

	}

	@Override
	public Flight searchFlight(int flightNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Flight> searchFlights() {
		// TODO Auto-generated method stub
		return flightList;
	}

	@Override
	public List<Flight> searchFlights(String source, String target) {
		
		List<Flight> foundFlights = new ArrayList<Flight>();
		
		for(Flight theFlight : flightList) {
			if(theFlight.getFlightsource().equalsIgnoreCase(source) && theFlight.getFlightDestination().equalsIgnoreCase(target)) {
				/*
				 * var++; pw.println("<tr>");
				 * pw.println("<td>"+theFlight.getFlightNumber()+"</td>");
				 * pw.println("<td>"+theFlight.getFlightsource()+"</td>");
				 * pw.println("<td>"+theFlight.getFlightDestination()+"</td>");
				 * pw.println("<td>"+theFlight.getFlightDepartureDate()+"</td>");
				 * pw.println("</tr>");
				 */
				
				foundFlights.add(theFlight);
			}
		}
		return foundFlights;
	}

}
