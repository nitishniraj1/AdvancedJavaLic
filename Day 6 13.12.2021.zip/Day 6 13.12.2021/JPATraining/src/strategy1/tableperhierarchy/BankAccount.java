package strategy1.tableperhierarchy;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity(name="BankAccount1")
@DiscriminatorValue("BA")
public class BankAccount extends BillingDetails {

	@Column(length=20)
	private String bankName;
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	@Override
	public String toString() {
		return "BankAccount [toString()=" + super.toString() + ", bankName=" + bankName + "]";
	}
	
	
}
