package onetomany;

public class Department {

}
